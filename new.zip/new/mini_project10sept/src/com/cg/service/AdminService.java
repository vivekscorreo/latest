package com.cg.service;
import java.sql.Date;
import java.util.ArrayList;

import com.cg.Exception.UASException;
import com.cg.dto.Application;
import com.cg.dto.ProgramOffered;
import com.cg.dto.ProgramScheduled;

public interface AdminService {

	boolean checkLogin(String loginId, String password);
	void addProgram(ProgramOffered obj);
	void deleteProgram(String programName);
	void scheduleProgram(ProgramScheduled obj);
	ArrayList<ProgramScheduled> getScheduledProgram(Date startDate, Date endDate);
	ArrayList<Application> getStatus(String status);
	ArrayList<String> getProgramsOffered();
	ArrayList<ProgramOffered> getProgramsOfferedDetails() throws UASException;
}
