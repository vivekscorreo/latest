package com.cg.QMapper;

public interface MACDAOQMapper {
	public static final String SELECT_ALL_PS = "SELECT * FROM Programs_Scheduled";
	public static final String UPDATE_STATUS = "Update Application set status=? where Application_id=?";
	public static final String SET_INTERVIEW = "Update Application set Date_Of_Interview=? where Application_id=?";
	public static final String APPLICANT_BY_STATUS = "SELECT * FROM Application where status=?";
	public static final String ALL_APPLICATIONS = "SELECT* FROM APPLICATION";
	public static final String STATUS_usingID = "SELECT STATUS FROM APPLICATION WHERE APPLICATION_ID=?";
}
