package com.cg.dao;

public interface UserDao {
	/*validateCredentials
	getRole()*/
	public String ReturnRole(String loginId, String password);
}
